plugins {
	alias(libs.plugins.versions)
}
