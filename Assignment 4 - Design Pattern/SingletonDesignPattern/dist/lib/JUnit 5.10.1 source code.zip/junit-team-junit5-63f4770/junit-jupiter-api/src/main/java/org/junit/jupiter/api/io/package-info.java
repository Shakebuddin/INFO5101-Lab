/**
 * IO-related support in JUnit Jupiter.
 */

package org.junit.jupiter.api.io;
